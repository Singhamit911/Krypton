package com.G12.request;

import lombok.Data;

@Data
public class PromptBody {
    private String prompt;
}
