package com.G12.exception;

public class OrderException extends Exception {
	
	public OrderException(String message) {
		super(message);
	}

}
