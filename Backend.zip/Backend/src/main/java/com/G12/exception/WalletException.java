package com.G12.exception;

public class WalletException extends Exception {

    public WalletException(String message){
        super(message);
    }
}
