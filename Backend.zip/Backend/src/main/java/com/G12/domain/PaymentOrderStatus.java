package com.G12.domain;

public enum PaymentOrderStatus {
    PENDING,SUCCESS,FAILED
}
