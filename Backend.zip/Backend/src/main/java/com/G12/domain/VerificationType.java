package com.G12.domain;

public enum VerificationType {
    MOBILE,
    EMAIL
}
