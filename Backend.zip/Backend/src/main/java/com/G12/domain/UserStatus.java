package com.G12.domain;

public enum UserStatus {

    VERIFIED,
    PENDING

}
