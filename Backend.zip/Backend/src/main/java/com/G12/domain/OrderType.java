package com.G12.domain;

public enum OrderType {
    BUY,
    SELL
}
