package com.G12.domain;

public enum WithdrawalStatus {
    PENDING,
    SUCCESS,
    DECLINE
}
