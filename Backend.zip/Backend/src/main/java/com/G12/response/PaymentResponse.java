package com.G12.response;

import lombok.Data;

@Data
public class PaymentResponse {


        private String payment_url ;


}
