package com.G12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradingPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
